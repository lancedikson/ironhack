
// Copyright Quch.io 2013

var QuchIronConstants = {
	ATTACHED: "attached"
};
