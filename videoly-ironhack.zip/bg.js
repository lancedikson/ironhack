
var quch = new QuchCore();
quch.run("/bg.js");
